import { Component } from '@angular/core';
@Component({
  templateUrl: 'orders.component.html'
})
export class OrderComponent {}

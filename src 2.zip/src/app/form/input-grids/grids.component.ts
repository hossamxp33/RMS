import { Component } from '@angular/core';

@Component({
  selector: 'app-input-grids',
  templateUrl: './grids.component.html',
  styleUrls: ['./grids.component.css']
})
export class GridsComponent {}

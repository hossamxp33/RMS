import { Component } from '@angular/core';

@Component({
  selector: 'app-form-inputs',
  templateUrl: './inputs.component.html',
  styleUrls: ['./inputs.component.css']
})
export class ForminputsComponent {}

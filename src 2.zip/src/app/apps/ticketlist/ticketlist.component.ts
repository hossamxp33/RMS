import { Component, AfterViewInit } from '@angular/core';
@Component({
  templateUrl: './ticketlist.component.html'
})
export class TicketlistComponent implements AfterViewInit {
  constructor() {}

  ngAfterViewInit() {}
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-items-report-filter',
  templateUrl: './items-report-filter.component.html',
  styleUrls: ['./items-report-filter.component.css']
})
export class ItemsReportFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

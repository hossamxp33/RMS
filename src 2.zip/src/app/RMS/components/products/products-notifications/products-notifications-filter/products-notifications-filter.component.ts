import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-notifications-filter',
  templateUrl: './products-notifications-filter.component.html',
  styleUrls: ['./products-notifications-filter.component.css']
})
export class ProductsNotificationsFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

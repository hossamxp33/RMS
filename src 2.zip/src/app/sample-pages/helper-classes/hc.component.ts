import { Component } from '@angular/core';
@Component({
  templateUrl: 'hc.component.html'
})
export class HelperclassesComponent {}

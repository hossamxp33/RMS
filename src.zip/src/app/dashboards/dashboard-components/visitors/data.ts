export const multi = [
  {
    name: 'Germany',
    series: [
      {
        name: '2010',
        value: 40
      },
      {
        name: '2000',
        value: 36
      },
      {
        name: '1990',
        value: 31
      }
    ]
  },
  {
    name: 'USA',
    series: [
      {
        name: '2010',
        value: 49
      },
      {
        name: '2000',
        value: 45
      },
      {
        name: '1990',
        value: 37
      }
    ]
  },
  {
    name: 'India',
    series: [
      {
        name: '2010',
        value: 36
      },
      {
        name: '2000',
        value: 34
      },
      {
        name: '1990',
        value: 29
      }
    ]
  },
  {
    name: 'Spain',
    series: [
      {
        name: '2010',
        value: 36
      },
      {
        name: '2000',
        value: 32
      },
      {
        name: '1990',
        value: 26
      }
    ]
  }
];

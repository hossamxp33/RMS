import { Component } from '@angular/core';
@Component({
  templateUrl: 'pricing.component.html'
})
export class PricingComponent {}

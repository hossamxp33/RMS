import { Component } from '@angular/core';
@Component({
  selector: 'app-visits-bounce',
  templateUrl: './visits-bounce.component.html'
})
export class VisitsBounceComponent {
  constructor() {}
}

import { Component } from '@angular/core';
@Component({
  templateUrl: 'iconmind.component.html'
})
export class IconmindComponent {}

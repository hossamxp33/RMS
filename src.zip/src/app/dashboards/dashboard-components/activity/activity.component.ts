import { Component } from '@angular/core';
@Component({
  selector: 'app-activity',
  templateUrl: './activity.component.html'
})
export class ActivityComponent {
  constructor() {}
}

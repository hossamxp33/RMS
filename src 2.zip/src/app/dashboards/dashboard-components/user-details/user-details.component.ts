import { Component } from '@angular/core';
@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html'
})
export class UserDetailsComponent {
  constructor() {}
}

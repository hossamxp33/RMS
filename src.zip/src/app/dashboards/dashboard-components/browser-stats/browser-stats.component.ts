import { Component } from '@angular/core';
@Component({
  selector: 'app-browser-stats',
  templateUrl: './browser-stats.component.html'
})
export class BrowserStatsComponent {
  constructor() {}
}

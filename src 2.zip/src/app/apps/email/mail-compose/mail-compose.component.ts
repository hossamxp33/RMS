import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-mail-compose',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './mail-compose.component.html'
})
export class MailComposeComponent { }
